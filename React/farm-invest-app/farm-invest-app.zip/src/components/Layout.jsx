// src/components/Layout.jsx
import React from "react";
import { Outlet, Link } from "react-router-dom";
// Можно подключить стили для хедера здесь

const Layout = () => {
  return (
    <div>
      <header
        style={{
          padding: "1rem",
          background: "#f0f0f0",
          display: "flex",
          gap: "15px",
        }}
      >
        {/* Вместо тега <a> используем Link для SPA-переходов */}
        <Link to="/">Home</Link>
        <Link to="/locations">Locations</Link>
        <Link to="/shop">Shop</Link>
        <Link to="/login">Login</Link>
      </header>

      <main style={{ padding: "1rem" }}>
        {/* Outlet — это место, куда подставляются дочерние страницы (Home, Locations и т.д.) */}
        <Outlet />
      </main>

      <footer style={{ marginTop: "20px", borderTop: "1px solid #ccc" }}>
        <p>© 2024 Farm Invest</p>
      </footer>
    </div>
  );
};

export default Layout;
