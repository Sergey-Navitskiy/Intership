import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Home from "../pages/Home";
import Locations from "../pages/Locations";
import Login from "../pages/Login";

//  Layout
const Layout = ({ children }) => (
  <div>
    <header
      style={{
        padding: "20px",
        borderBottom: "1px solid #ccc",
        display: "flex",
        gap: "20px",
      }}
    >
      <Link to="/">Home</Link>
      <Link to="/locations">Locations</Link>
      <Link to="/login">Login</Link>
    </header>
    <main>{children}</main>
  </div>
);

const App = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/locations" element={<Locations />} />
        <Route path="/login" element={<Login />} />
        {/* Можно добавить 404 */}
        <Route path="*" element={<div>Page not found</div>} />
      </Routes>
    </Layout>
  );
};

export default App;
